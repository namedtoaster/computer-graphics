#ifndef HOUSE_H
#define HOUSE_H

#include "Model.h"

class House: public Model {
    /*House(char filename[])
        : model(filename)
    {
        //model(filename);
    }*/
private:
    Model model;
};

#endif
