#ifndef 3DMODELS_H
#define 3DMODELS_H

#include "Model.cpp"
#include "Model.h"
#include "Light.cpp"
#include "Light.h"
#include "Surface.cpp"
#include "Surface.h"
#include "House.h"

#endif
