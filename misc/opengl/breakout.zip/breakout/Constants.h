#ifndef CONSTANTS_H
#define CONSTANTS_H

const double LEFT = -7.0;
const double RIGHT = 7.0;

#endif
