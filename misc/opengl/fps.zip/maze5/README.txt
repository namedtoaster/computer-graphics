Controls:

'a': turn clockwise
'd': turn counter-clockwise

Left mouse click: fire

The following controls are with respect to world origin (which remains at (0,0) and does not rotate)

UP: move forward
DOWN: move backward
LEFT: move left
RIGHT: move right


Note:

Collision detection does not take into account the weapon. It only calculates the collision with the invisible box around the player and the walls thus allowing the weapon to "go through" the wall at times
